Main: file mana yang pertama kali dijalankan
script: shortcut buat akan yang dijalankan
license: project license
type: pilihannya 2: commonjs dan module (perbedaannya dalam hal import module,package dan file )

commonjs -- require (buat manggil package)
module-- import .. from

"SELECT * FROM products" pilih data semua kolom(*) dan ambil dari (tabel) products
"SELECT product_name, product_price FROM products" kalau mau ambil sebagain

contoh statuscode
400 
500 
200 api success
201 success created

404 NOt found

Proses ngisi 
router.get("/", productController.getProducts)

.. (titik dua) keluar dari folder
. (titik satu) tetap di folder