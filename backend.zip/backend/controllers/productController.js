const db = require ("../configs/db")

const getProducts = (req, res) => {
    const {
        search,
        sortBy,
        sortOrder,
        page,
        limit
    } = req.query

    let query = "SELECT * FROM products"
    const params = []

    if (search) {
        query += " WHERE product_name LIKE ?"
        params.push(`%${search}%`)
    }

    if (sortBy && sortOrder) {
        query += ` ORDER BY ${sortBy} ${sortOrder}`
    }

    const pageNumber = parseInt(page) || 1
    const limitNumber = parseInt(limit) || 10
    const offset = (pageNumber - 1) * limitNumber

    query += " LIMIT ? OFFSET ?"
    params.push(limitNumber, offset)

    db.query(query, params, (error, result) => {
        if (error) return res.status(500).json({
            error: error.message
        })

        let countQuery = "SELECT COUNT(*) as total FROM products"
        const countParams = []

        if (search) {
            countQuery += " WHERE product_name LIKE ?"
            countParams.push(`%${search}%`)
        }

        db.query(countQuery, countParams, (error, countResult) => {
            if (error) return res.status(500).json({
                error: error.message
            })

            const total = countResult[0].total
            const totalPages = Math.ceil(total / limitNumber)

            res.status(200).json({
                total,
                totalPages,
                page: pageNumber,
                limit: limitNumber,
                data: result
            })
        })
    })
}

const createProduct = (req, res) => {
    const { product_name, product_description, product_price} = req.body
    const query = "INSERT INTO products (product_name, product_description, product_price) VALUES (?, ?, ?)"
    db.query(query, [product_name, product_description, product_price], (error, result) => {
        if (error) {
            return res.status(500).json({
                error: error.message
            })
        }
        res.status(201).json({
            id: result.insertId,
            product_name,
            product_description,
            product_price
        })
    })
}

const getProductById = (req, res) => {
    const { id } = req.params
    const query = "SELECT * FROM products WHERE id = ?"
    db.query(query, [id], (error, result) => {
        if (error) {
            return res.status(500).json({
                error: error.message
            })
        }
        if (result.length === 0) {
            return res.status(404).json({
                error: "Product not found"
            })
        }
        res.status(200).json(result[0])
    })
}

const updateProduct = (req, res) => {
    const { id } = req.params
    const { product_name, product_description, product_price } = req.body
    const query = "UPDATE products SET product_name = ?, product_description = ?, product_price = ? WHERE id = ?"
    db.query(query, [product_name, product_description, product_price, id], (error, result) => {
        if (error) {
            return res.status(500).json({
                error: error.message
            })
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({
                error: "Product not found"
            })
        }
        res.status(200).json({
            id,
            product_name,
            product_description,
            product_price
        })
    })
}

const deleteProduct = (req, res) => {
    const { id } = req.params
    const query = "DELETE FROM products WHERE id = ?"
    db.query(query, [id], (error, result) => {
        if (error) {
            return res.status(500).json({
                error: error.message
            })
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({
                error: "Product not found"
            })
        }
        res.status(200).json({
            message: "Product deleted successfully"
        })
    })
}

module.exports = {
    getProducts,
    createProduct,
    getProductById,
    updateProduct,
    deleteProduct
}
